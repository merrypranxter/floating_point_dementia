# floating_point_dementia

> IEEE-754 precision tearing toward far UVs. When numbers lose their minds.

## What This Is

Floating-point arithmetic is an approximation. As numbers get very large or very small, precision degrades. Far from 1.0, the gaps between representable numbers grow. Operations that should be simple become lossy, then meaningless, then **visually spectacular**.

This repo explores the visual aesthetics of floating-point breakdown:
- **Precision loss** — as numbers drift from 1.0, details dissolve
- **Denormalized numbers** — the "gradual underflow" zone where precision collapses
- **Infinity and NaN** — what happens when math gives up
- **Catastrophic cancellation** — subtracting nearly-equal large numbers
- **Order-of-operations sensitivity** — `(a+b)+c ≠ a+(b+c)` made visible

## Visual Phenomena

### 1. Precision Tearing
As the camera zooms out, precision drops. Objects jitter, then fragment, then dissolve into quantization noise.

```glsl
// Precision tearing simulation
float far_field(float x) {
    // At large x, x + 1.0 == x (no change!)
    float coarse = x + 1.0;
    float fine = fract(x);  // Only the mantissa bits
    return mix(fine, noise(coarse), smoothstep(1e4, 1e7, x));
}
```

### 2. UV Distortion at Extremes
Texture coordinates that wrap correctly near origin become garbage at ±1e20.

### 3. Z-Fighting on Cosmic Scales
Parallel planes that are distinct near the camera become indistinguishable, then swap randomly.

### 4. Denormal Underflow
Numbers below ~1e-38 (float32) lose precision exponentially. Visualized as a "fog" of uncertainty.

### 5. NaN Propagation
Once a NaN enters your computation, it infects everything. Visualized as a spreading purple corruption.

## The Far UV Aesthetic

"Far UVs" refers to UV coordinates far from the [0,1] range where textures are defined. The visual result is:
- **Quantization bands** — visible steps where precision runs out
- **Periodicity breakdown** — `sin(x)` at x=1e10 looks like noise
- **Aliasing** — Nyquist failure at extreme frequencies
- **Fractal structure** — the bits themselves become visible

## Parameters

- `distance_from_origin` — how far into the precision desert
- `zoom_rate` — speed of precision collapse
- `operation_type` — add / subtract / multiply / divide / sqrt / log
- `show_bits` — visualize the raw IEEE-754 bit pattern
- `corruption_mode` — NaN purple / Inf white / denormal gray

## Shader Architecture

```glsl
// Floating-point dementia core
vec3 render_demented(vec2 uv, float distance) {
    // Normal precision zone
    vec3 color = normal_render(uv);
    
    // Precision loss zone: show quantization
    float precision_bits = 23.0 - log2(distance); // float32 mantissa
    if (precision_bits < 5.0) {
        vec3 quantized = quantize(color, precision_bits);
        vec3 noise = hash23(uv * distance);
        color = mix(quantized, noise, 1.0 - precision_bits/5.0);
    }
    
    // Denormal zone: fade to gray uncertainty
    if (distance > 1e38) {
        color = mix(color, vec3(0.5), 0.5);
    }
    
    // Infinity: blow out to white
    if (isinf(distance)) {
        color = vec3(1.0, 0.9, 0.8); // warm white
    }
    
    // NaN: purple corruption
    if (isnan(distance) || isnan(color.r)) {
        color = vec3(0.8, 0.0, 1.0) * (0.5 + 0.5 * sin(iTime));
    }
    
    return color;
}
```

## Variations

### `floating_point_dementia/`
```
├── shaders/
│   ├── core/
│   │   ├── precision_sim.glsl    # IEEE-754 behavior model
│   │   ├── quantization.glsl     # bit-level quantization
│   │   └── corruption.glsl       # NaN/Inf spread
│   ├── phenomena/
│   │   ├── precision_tearing.frag # zoom-based dissolution
│   │   ├── z_fight_cosmic.frag   // extreme-distance flicker
│   │   ├── denormal_fog.frag     // underflow uncertainty
│   │   └── nan_corruption.frag   // purple infection
│   └── demo/
│       ├── journey_to_inf.frag   // camera zooms to infinity
│       ├── math_breakdown.frag   // operations fail visibly
│       └── bit_reveal.frag       // raw IEEE-754 visualization
└── docs/
    ├── ieee754_details.md
    └── precision_loss.md
```

## References

- Goldberg (1991). *What every computer scientist should know about floating-point arithmetic*
- IEEE 754-2008 standard
- Muller et al. (2018). *Handbook of Floating-Point Arithmetic*

## Related

- `false_vacuum_decay_front` — shared "things fall apart" aesthetic
- `abandoned_orphaned_memory` — shared digital-debris theme

---

*Your GPU believes 1.0 + 1e-8 = 1.0. At sufficient scale, everything is equal to everything else.*
